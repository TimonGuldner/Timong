#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
The example.py is deprecated. Please use the declarative mode with YAML settings
Please refer to Github README + (instabot -h) + Blog section for further information
"""
print(__doc__)